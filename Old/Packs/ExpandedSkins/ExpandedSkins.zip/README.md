﻿## General information
This mod adds 10 new skins to each character for each vanilla skin they have, first-time setup will take a very long while as it generates all the new skins programmatically, but afterwards it will take significantly less time

The first time you run this mod, it will generate the textures for the skins.
every time after that, it needs to load the textures into the engine, as we cannot permanently save the skins.
starting this mod up will take a long time the first time, and a while after that.

### Multiplayer compatibility
Only you need the mod to see your skins, but if both people have the mod, you can see eachother's skins.

### Updates:

#### 1.1.0
Now works to generate skins for custom survivors
Slight Message improvements
Slight Speed improvements
Now includes config file for what to load.
Config now works for custom survivors.

