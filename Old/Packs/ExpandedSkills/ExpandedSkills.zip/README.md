﻿### General information
This mod adds multiple new mostly balanced skills to existing survivors.


