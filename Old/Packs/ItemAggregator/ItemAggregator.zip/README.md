﻿##General information
This mod adds the ability for enemies to aggregate items per level, similar to the void fields.

### Multiplayer compatibility
Only the host needs the mod, other players will get UI if they have it installed.