﻿## General information

Adds a new custom character that is very item-synergistic.

### Multiplayer compatibility
Everyone needs this mod.
