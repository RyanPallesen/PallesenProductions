﻿#Discord
https://discord.gg/TkKUkyq

Currently contains 3 elites, 18 unique skills and 4 artifacts. more planned and in progress.